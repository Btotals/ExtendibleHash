#include"extended_hash.h"

#define  INPUT (page[PAGE_NUMBER-2])
#define  INDEX (page[PAGE_NUMBER-1])

char index[100];
char BUCKET[100];
char IN[100];
char OUT[100];
char TBL[100];
char TEMP[100];
int FileSize = 0;

Hash h;
int main(int argc, char ** argv) {
	/*
  char c[20];
  for (int i = 0; i < 20; i++) c[i] = 'a';
  c[0] = '1';
  c[1] = '|';
  c[19] = '\n';
  for (int i = 0; i < 300; i++)
  h.insert(Tuple(c));
  c[0] = '0';
  for (int i = 0; i < 300; i++)
  h.insert(Tuple(c));

  

  for (int i = 0; i < PAGE_NUMBER-2; i++) {
    if (h.page[i].is_used) {
      cout << h.page[i].Bucketid << endl;
      cout << h.page[i].used_size << endl << -1 << endl;
    }
  }
  */


  strcpy(BUCKET, argv[1]);
  strcat(BUCKET, "\\hashbucket.out");
  strcpy(index, argv[1]);
  strcat(index, "\\hashindex.out");
  strcpy(IN, argv[1]);
  strcat(IN, "\\testinput.in");
  strcpy(OUT, argv[1]);
  strcat(OUT, "\\testoutput.out");
  strcpy(TBL, argv[1]);
  strcat(TBL, "\\lineitem.tbl");

  FILE* CurrentPointer = fopen(TBL, "rb+");
  fseek(CurrentPointer, 0, SEEK_END);
  FileSize = ftell(CurrentPointer);
  fclose(CurrentPointer);

  FILE* fp = fopen(BUCKET, "wb+");
  fclose(fp);
  fp = fopen(index, "wb+");
  fclose(fp);
  fp = fopen(OUT, "wb+");
  fclose(fp);

  cout << "��ʼ��������\n";
  h.read_tuple();
  cout << "Complete\n";
}

Hash::Hash() {
  global_depth = 1;
  IOs = 0;
  mode = 1; //least mode
  page[0].is_used = true;
  page[0].Bucketid = 0;
  page[1].is_used = true;
  page[1].Bucketid = 1;
  bucket[0].depth = 1;
  bucket[1].depth = 1;
  index_offset = 0;
  char* c = page[PAGE_NUMBER-1].ptr;
  c[0] = 1; // local delth
  c[1] = 1;
  page[PAGE_NUMBER-1].used_size = 2;
}

Hash::~Hash() {

}

int Hash::get_page() {  //get a empty page, or evict a page from the memory, return the pageid
  for (int i = 0; i < PAGE_NUMBER-2; i++) {
    if (!page[i].is_used) {
      page[i].is_used = true;
      return i;
    }
  }
  return evict_page();
}

int Hash::evict_page() { //choose a page to evict and clean it, return the pageid
  for (int i = 0;; i++) {
  	if (i == PAGE_NUMBER-2) i = 0;
  	if (!page[i].locked){
  	
    if (page[i].accessed) {
      page[i].accessed = false;
    } else {
      write_bucket_to_file(i);
      memset(page[i].ptr,0, PAGE_SIZE);
      page[i].used_size = 0;
      return i;
    }
    
	}
  }
}

int Hash::global_key(Tuple t) {
  unsigned int temp = t.key;
  int jump = 32-global_depth;
  if (mode == 1) {
  	temp = (temp << jump) >> jump;
  }
  else {
	  int a[23];
	  for (int i = 0; i < 23; i++) {
		  a[i] = temp % 2;
		  temp /= 2;
	  }
	  for (int i = 23-global_depth; i < 23; i++) temp = temp * 2 + a[i];
  }
  return temp;
}

void Hash::inc_localdepth(int bucketid) {
  if (bucketid/PAGE_SIZE != index_offset) {
	write_index_to_file();
	read_index_from_file(bucketid/PAGE_SIZE);
  }
  page[PAGE_NUMBER-1].ptr[bucketid%PAGE_SIZE]++;
}

int Hash::final_key(Tuple t) {
  unsigned int gkey = global_key(t);
  if (gkey/PAGE_SIZE != index_offset) {
    write_index_to_file();
    read_index_from_file(gkey/PAGE_SIZE);
  }
  int temp = page[PAGE_NUMBER-1].ptr[gkey%PAGE_SIZE];
  int jump = 32-temp;
  //if (mode == 1) {
  	gkey = (gkey << jump) >> jump;
  //}
  return gkey;
}

void Hash::insert(Tuple t){
  int hkey = final_key(t);
  int index = -1, index2;
  //search the bucket of key(hkey)
  for (int i = 0; i < PAGE_NUMBER-2; i++) {
    if (page[i].Bucketid == hkey) {
      index = i;
      break;
    }
  }
  //if the bucket was not in the memory, get a page
  if (index == -1) {
    index = get_page();
    read_bucket_from_file(hkey, index);
  }
  //if the page is overflow, split
  while (page[index].used_size+t.length > PAGE_SIZE) {
  	page[index].locked = true;
    index2 = split(index);
    page[index].locked = false;
    hkey = final_key(t);
    if (page[index2].Bucketid == hkey) index = index2;
  }
  //insert the tuple
  int temp = page[index].used_size;
  for (int i = 0; i < t.length; i++) {
    page[index].ptr[temp++] = t.data[i];
  }
  page[index].used_size = temp;
  page[index].accessed = true;
}

int Hash::split(int pageid){
  int bid = page[pageid].Bucketid;
  unsigned int bid2 = 1;
  bid2 = (bid2<<bucket[pageid].depth)+bid;
  int newid = get_page();
  page[newid].Bucketid = bid2;

  if (bid2 / PAGE_SIZE != index_offset) {
	  write_index_to_file();
	  read_index_from_file(bid2 / PAGE_SIZE);
  }
  page[PAGE_NUMBER - 1].ptr[bid2%PAGE_SIZE] = bucket[pageid].depth;

  if (global_depth == bucket[pageid].depth) {
    double_the_index();
  }
  inc_localdepth(bid);
  inc_localdepth(bid2);
  int len = page[pageid].used_size;
  bucket[pageid].depth = bucket[newid].depth = bucket[pageid].depth+1;
  page[pageid].used_size = page[newid].used_size = 0;
  char *c = page[pageid].ptr;
  char *d = page[newid].ptr;
  int dep = bucket[pageid].depth;
  for (int i = 0; i < len;) {
  	unsigned int num = 0;
  	for (int j = i; c[j] != '|'; j++) {
  	  num = num*10+(c[j]-'0');
  	}
  	if (mode == 1) {
  	  num = (num<<(32-dep))>>(32-dep);
	}
	else {
		int a[23];
		for (int i = 0; i < 23; i++) {
			a[i] = num % 2;
			num /= 2;
		}
		for (int i = 23 - dep; i < 23; i++) num = num * 2 + a[i];
	}
  	if (num == page[pageid].Bucketid) {
  	  for (int j = i; c[j] != '\n'; j++) {
  	  	c[page[pageid].used_size++] = c[j];
  	  }
  	  c[page[pageid].used_size++] = '\n';
  	} else {
  	  for (int j = i; c[j] != '\n'; j++) {
  	  	d[page[newid].used_size++] = c[j];
  	  }
  	  d[page[newid].used_size++] = '\n';
  	}
  	i = page[pageid].used_size+page[newid].used_size;
  }
  return newid;
}
void Hash::double_the_index() {
  int totalindex = 1;
  char *c = page[PAGE_NUMBER-1].ptr;
  for (int i = 0; i < global_depth; i++) totalindex *= 2;  //calculate the total number of index
  
  if (global_depth < 13) {  // which means that a page is big enough to hold all the index
  	for (int i = 0; i < totalindex; i++) {
  	  c[i+totalindex] = c[i];
  	}
  	page[PAGE_NUMBER-1].used_size *= 2;
  	write_index_to_file();
  } else {
  	  int count = totalindex/PAGE_SIZE;
  	  write_index_to_file();
  	  for (int i = 0; i < count; i++) {
  	    read_index_from_file(i);
  	    index_offset += count;
  	    write_index_to_file();
  	  }
  }
  global_depth++;
}

void Hash::read_tuple() {
	int temp = 0;
	while (read_tuple_from_file(temp)) {
		temp += page[PAGE_NUMBER - 2].used_size;
		char *c = page[PAGE_NUMBER - 2].ptr;
		int length = page[PAGE_NUMBER - 2].used_size;
		for (int i = 0; i < length;) {
			Tuple t(c);
			insert(t);
			i += t.length;
			c += t.length;
		}
	}
}

void Hash::write_bucket_to_file(int pageid){
	FILE* CurrentPointer = fopen(BUCKET, "rb+");
	int bucketid = page[pageid].Bucketid;

	fseek(CurrentPointer, bucketid*PAGE_SIZE, SEEK_SET);
	fwrite(page[pageid].ptr, page[pageid].used_size, 1, CurrentPointer);

	fclose(CurrentPointer);
}

void Hash::write_index_to_file(){
	FILE* CurrentPointer = fopen(index, "rb+");

	fseek(CurrentPointer, index_offset*PAGE_SIZE, SEEK_SET);
	fwrite(INDEX.ptr, INDEX.used_size, 1, CurrentPointer);

	fclose(CurrentPointer);
}

void Hash::read_index_from_file(int offset){
	FILE* CurrentPointer = fopen(index, "rb+");

	fseek(CurrentPointer, offset*PAGE_SIZE, SEEK_SET);
	fread(INDEX.ptr, PAGE_SIZE, 1, CurrentPointer);
	index_offset = offset;
	fclose(CurrentPointer);
}
bool Hash::read_tuple_from_file(int offset){
	FILE* CurrentPointer = fopen(TBL, "rb+");
	int ReadSize = offset + PAGE_SIZE > FileSize ? FileSize - offset : PAGE_SIZE;

	fseek(CurrentPointer, offset, SEEK_SET);
	fread(INPUT.ptr, ReadSize, 1, CurrentPointer);

	while (INPUT.ptr[ReadSize - 1] != '\n')
		ReadSize--;

	INPUT.used_size = ReadSize;

	return offset + PAGE_SIZE > FileSize ? false : true;

}
void Hash::read_bucket_from_file(int bucketid, int pageid){
	FILE* CurrentPointer = fopen(BUCKET, "rb+");

	fseek(CurrentPointer, bucketid*PAGE_SIZE, SEEK_SET);
	fread(page[pageid].ptr, PAGE_SIZE, 1, CurrentPointer);
	page[pageid].Bucketid = bucketid;
	page[pageid].used_size = PAGE_SIZE;
	for (int i = PAGE_SIZE - 1; i >= 0; i--) {
		if (page[pageid].ptr[i] != '\0') break;
		page[pageid].used_size--;
	}

	fclose(CurrentPointer);
}